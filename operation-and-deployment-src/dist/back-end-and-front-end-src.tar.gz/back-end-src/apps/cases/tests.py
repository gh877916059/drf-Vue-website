# -*- coding: utf-8 -*-
__author__ = 'HymanLu'

from django.test import TestCase

# Create your tests here.
