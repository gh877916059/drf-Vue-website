# -*- coding: utf-8 -*-
__author__ = 'HymanLu'

from django.apps import AppConfig

class CasesConfig(AppConfig):
    name = 'cases'
    verbose_name = "案例"